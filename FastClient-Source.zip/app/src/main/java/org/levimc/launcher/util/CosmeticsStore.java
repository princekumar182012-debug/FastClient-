package org.levimc.launcher.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

/** Stores the player's skin, cape and nametag colour chosen inside the launcher. */
public final class CosmeticsStore {

    private static final String PREFS = "fast_cosmetics";
    private static final String KEY_TAG_COLOR = "tag_color";
    public static final int DEFAULT_TAG_COLOR = 0xFFFF7A1A;

    private CosmeticsStore() {}

    private static File dir(Context c) {
        File d = new File(c.getFilesDir(), "cosmetics");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    private static Bitmap load(File f) {
        if (!f.exists()) return null;
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inScaled = false;
        return BitmapFactory.decodeFile(f.getAbsolutePath(), o);
    }

    public static Bitmap loadSkin(Context c) {
        return load(new File(dir(c), "skin.png"));
    }

    public static Bitmap loadCape(Context c) {
        return load(new File(dir(c), "cape.png"));
    }

    public static boolean saveSkin(Context c, Uri uri) {
        return saveImage(c, uri, "skin.png", true);
    }

    public static boolean saveCape(Context c, Uri uri) {
        return saveImage(c, uri, "cape.png", false);
    }

    public static void clearCape(Context c) {
        File f = new File(dir(c), "cape.png");
        if (f.exists()) f.delete();
    }

    private static boolean saveImage(Context c, Uri uri, String name, boolean isSkin) {
        try (InputStream in = c.getContentResolver().openInputStream(uri)) {
            if (in == null) return false;
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inScaled = false;
            Bitmap b = BitmapFactory.decodeStream(in, null, o);
            if (b == null) return false;
            int w = b.getWidth();
            int h = b.getHeight();
            boolean okSize = w % 64 == 0 && (isSkin ? (h == w || h * 2 == w) : (h * 2 == w));
            if (!okSize) return false;
            try (FileOutputStream out = new FileOutputStream(new File(dir(c), name))) {
                b.compress(Bitmap.CompressFormat.PNG, 100, out);
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static int getTagColor(Context c) {
        return prefs(c).getInt(KEY_TAG_COLOR, DEFAULT_TAG_COLOR);
    }

    public static void setTagColor(Context c, int color) {
        prefs(c).edit().putInt(KEY_TAG_COLOR, color).apply();
    }
}
