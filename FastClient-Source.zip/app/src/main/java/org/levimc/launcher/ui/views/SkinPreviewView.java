package org.levimc.launcher.ui.views;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.View;

import org.levimc.launcher.R;

/** Draws a simple blocky player model (front or back) from a standard 64x64 / 64x32 skin PNG. */
public class SkinPreviewView extends View {

    private Bitmap skin;
    private Bitmap defaultSkin;
    private Bitmap cape;
    private Bitmap tagLogo;
    private boolean showBack = false;
    private boolean showTag = false;
    private int tagColor = 0xFFFF7A1A;
    private String tagName = "Player";

    private final Paint paint = new Paint();
    private final Paint tagBg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint logoPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Rect src = new Rect();
    private final RectF dst = new RectF();

    public SkinPreviewView(Context context) {
        super(context);
        init();
    }

    public SkinPreviewView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public SkinPreviewView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        paint.setFilterBitmap(false);
        paint.setAntiAlias(false);
        tagBg.setColor(0xAA000000);
        textPaint.setColor(Color.WHITE);
        textPaint.setFakeBoldText(true);
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inScaled = false;
        defaultSkin = BitmapFactory.decodeResource(getResources(), R.drawable.default_skin, o);
        BitmapFactory.Options lo = new BitmapFactory.Options();
        lo.inSampleSize = 8;
        tagLogo = BitmapFactory.decodeResource(getResources(), R.drawable.ic_leaf_logo, lo);
        setOnClickListener(v -> toggleSide());
    }

    public void setSkin(Bitmap bmp) {
        this.skin = bmp;
        invalidate();
    }

    public void setCape(Bitmap bmp) {
        this.cape = bmp;
        invalidate();
    }

    public void setTag(boolean show, String name, int color) {
        this.showTag = show;
        if (name != null) this.tagName = name;
        this.tagColor = color;
        invalidate();
    }

    public void setShowBack(boolean back) {
        this.showBack = back;
        invalidate();
    }

    public void toggleSide() {
        showBack = !showBack;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        Bitmap s = skin != null ? skin : defaultSkin;
        if (s == null) return;
        float w = getWidth();
        float h = getHeight();
        float tagH = showTag ? Math.min(h * 0.14f, 34f * getResources().getDisplayMetrics().density) : 0f;
        float availH = h - tagH;
        float unit = Math.min((w * 0.9f) / 16f, (availH * 0.94f) / 32f);
        float cx = w / 2f;
        float top = tagH + (availH - 32f * unit) / 2f;

        double t = SystemClock.uptimeMillis();
        float sx = (float) Math.cos(0.4 * Math.sin(t / 1100.0));

        c.save();
        c.scale(sx, 1f, cx, h / 2f);
        if (showBack) drawBack(c, s, cx, top, unit); else drawFront(c, s, cx, top, unit);
        c.restore();

        if (showTag) drawTag(c, cx, Math.max(0f, top - tagH * 1.15f), tagH);
        postInvalidateOnAnimation();
    }

    private void part(Canvas c, Bitmap s, int sx, int sy, int sw, int sh, boolean mirror,
                      float dx, float dy, float dw, float dh) {
        float f = s.getWidth() / 64f;
        src.set(Math.round(sx * f), Math.round(sy * f), Math.round((sx + sw) * f), Math.round((sy + sh) * f));
        if (src.right > s.getWidth() || src.bottom > s.getHeight()) return;
        dst.set(dx, dy, dx + dw, dy + dh);
        if (mirror) {
            c.save();
            c.scale(-1f, 1f, dx + dw / 2f, dy);
            c.drawBitmap(s, src, dst, paint);
            c.restore();
        } else {
            c.drawBitmap(s, src, dst, paint);
        }
    }

    private void layer(Canvas c, Bitmap s, int sx, int sy, int sw, int sh, float dx, float dy, float dw, float dh, float grow) {
        part(c, s, sx, sy, sw, sh, false, dx - grow, dy - grow, dw + grow * 2f, dh + grow * 2f);
    }

    private void drawFront(Canvas c, Bitmap s, float cx, float top, float u) {
        boolean legacy = s.getHeight() < s.getWidth();
        float l = cx - 8f * u;
        // legs
        part(c, s, 4, 20, 4, 12, false, l + 4f * u, top + 20f * u, 4f * u, 12f * u);
        if (legacy) part(c, s, 4, 20, 4, 12, true, l + 8f * u, top + 20f * u, 4f * u, 12f * u);
        else part(c, s, 20, 52, 4, 12, false, l + 8f * u, top + 20f * u, 4f * u, 12f * u);
        // body
        part(c, s, 20, 20, 8, 12, false, l + 4f * u, top + 8f * u, 8f * u, 12f * u);
        // arms
        part(c, s, 44, 20, 4, 12, false, l, top + 8f * u, 4f * u, 12f * u);
        if (legacy) part(c, s, 44, 20, 4, 12, true, l + 12f * u, top + 8f * u, 4f * u, 12f * u);
        else part(c, s, 36, 52, 4, 12, false, l + 12f * u, top + 8f * u, 4f * u, 12f * u);
        // head
        part(c, s, 8, 8, 8, 8, false, l + 4f * u, top, 8f * u, 8f * u);
        if (!legacy) {
            layer(c, s, 4, 36, 4, 12, l + 4f * u, top + 20f * u, 4f * u, 12f * u, 0.15f * u);
            layer(c, s, 4, 52, 4, 12, l + 8f * u, top + 20f * u, 4f * u, 12f * u, 0.15f * u);
            layer(c, s, 20, 36, 8, 12, l + 4f * u, top + 8f * u, 8f * u, 12f * u, 0.15f * u);
            layer(c, s, 44, 36, 4, 12, l, top + 8f * u, 4f * u, 12f * u, 0.15f * u);
            layer(c, s, 52, 52, 4, 12, l + 12f * u, top + 8f * u, 4f * u, 12f * u, 0.15f * u);
        }
        layer(c, s, 40, 8, 8, 8, l + 4f * u, top, 8f * u, 8f * u, 0.3f * u);
    }

    private void drawBack(Canvas c, Bitmap s, float cx, float top, float u) {
        boolean legacy = s.getHeight() < s.getWidth();
        float l = cx - 8f * u;
        // legs (viewer left = character left)
        if (legacy) part(c, s, 12, 20, 4, 12, true, l + 4f * u, top + 20f * u, 4f * u, 12f * u);
        else part(c, s, 28, 52, 4, 12, false, l + 4f * u, top + 20f * u, 4f * u, 12f * u);
        part(c, s, 12, 20, 4, 12, false, l + 8f * u, top + 20f * u, 4f * u, 12f * u);
        // body
        part(c, s, 32, 20, 8, 12, false, l + 4f * u, top + 8f * u, 8f * u, 12f * u);
        // arms
        if (legacy) part(c, s, 52, 20, 4, 12, true, l, top + 8f * u, 4f * u, 12f * u);
        else part(c, s, 44, 52, 4, 12, false, l, top + 8f * u, 4f * u, 12f * u);
        part(c, s, 52, 20, 4, 12, false, l + 12f * u, top + 8f * u, 4f * u, 12f * u);
        // head
        part(c, s, 24, 8, 8, 8, false, l + 4f * u, top, 8f * u, 8f * u);
        if (!legacy) {
            layer(c, s, 12, 52, 4, 12, l + 4f * u, top + 20f * u, 4f * u, 12f * u, 0.15f * u);
            layer(c, s, 12, 36, 4, 12, l + 8f * u, top + 20f * u, 4f * u, 12f * u, 0.15f * u);
            layer(c, s, 32, 36, 8, 12, l + 4f * u, top + 8f * u, 8f * u, 12f * u, 0.15f * u);
            layer(c, s, 60, 52, 4, 12, l, top + 8f * u, 4f * u, 12f * u, 0.15f * u);
            layer(c, s, 52, 36, 4, 12, l + 12f * u, top + 8f * u, 4f * u, 12f * u, 0.15f * u);
        }
        layer(c, s, 56, 8, 8, 8, l + 4f * u, top, 8f * u, 8f * u, 0.3f * u);
        // cape
        if (cape != null) {
            float f = cape.getWidth() / 64f;
            src.set(Math.round(1 * f), Math.round(1 * f), Math.round(11 * f), Math.round(17 * f));
            if (src.right <= cape.getWidth() && src.bottom <= cape.getHeight()) {
                dst.set(cx - 5f * u, top + 8f * u, cx + 5f * u, top + 24f * u);
                c.drawBitmap(cape, src, dst, paint);
            }
        }
    }

    private void drawTag(Canvas c, float cx, float y, float tagH) {
        if (tagH <= 0) return;
        textPaint.setTextSize(tagH * 0.5f);
        float tw = textPaint.measureText(tagName);
        float pad = tagH * 0.28f;
        float logo = tagH * 0.72f;
        float total = (tagLogo != null ? logo + pad : 0f) + tw + pad * 2f;
        float x = cx - total / 2f;
        dst.set(x, y, x + total, y + tagH);
        c.drawRoundRect(dst, tagH * 0.22f, tagH * 0.22f, tagBg);
        float tx = x + pad;
        if (tagLogo != null) {
            logoPaint.setColorFilter(new PorterDuffColorFilter(tagColor, PorterDuff.Mode.SRC_IN));
            RectF lr = new RectF(tx, y + (tagH - logo) / 2f, tx + logo, y + (tagH + logo) / 2f);
            c.drawBitmap(tagLogo, null, lr, logoPaint);
            tx += logo + pad;
        }
        Paint.FontMetrics fm = textPaint.getFontMetrics();
        c.drawText(tagName, tx, y + tagH / 2f - (fm.ascent + fm.descent) / 2f, textPaint);
    }
}
