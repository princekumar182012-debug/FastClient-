package org.levimc.launcher.core.mods.inbuilt.overlay;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;

/**
 * Minecraft Bedrock style button: 1 unit black outline, 1 unit bevel (light on top/left, dark on
 * bottom/right) and a flat grey face. Colours were measured from the in-game "Play" button.
 */
public class MinecraftButtonDrawable extends Drawable {
    public static final int BORDER = 0xFF131313;
    public static final int FACE = 0xFFC6C6C6;
    public static final int HIGHLIGHT = 0xFFF7F7F7;
    public static final int SHADOW = 0xFF656465;
    private static final int CORNER_TL = 0xFFFFFFFF;
    private static final int CORNER_TR = 0xFFC0BFC0;
    private static final int CORNER_BL = 0xFFBFBEBF;
    private static final int CORNER_BR = 0xFF595759;
    public static final int FACE_PRESSED = 0xFF9E9E9E;
    public static final int TEXT = 0xFF4C4C4C;

    private final boolean pressed;
    private final Paint paint = new Paint();

    public MinecraftButtonDrawable(boolean pressed) {
        this.pressed = pressed;
        paint.setAntiAlias(false);
        paint.setStyle(Paint.Style.FILL);
    }

    private void fill(Canvas c, int l, int t, int r, int b, int color) {
        if (r <= l || b <= t) return;
        paint.setColor(color);
        c.drawRect(l, t, r, b, paint);
    }

    @Override
    public void draw(Canvas c) {
        Rect b = getBounds();
        int w = b.width();
        int h = b.height();
        if (w <= 0 || h <= 0) return;
        int u = Math.max(2, Math.round(h / 29f));
        u = Math.min(u, Math.min(w, h) / 4);
        if (u < 1) u = 1;

        int l = b.left, t = b.top, r = b.right, bo = b.bottom;
        fill(c, l, t, r, bo, BORDER);

        int il = l + u, it = t + u, ir = r - u, ib = bo - u;
        int hi = pressed ? SHADOW : HIGHLIGHT;
        int lo = pressed ? HIGHLIGHT : SHADOW;

        fill(c, il, it, ir, ib, pressed ? FACE_PRESSED : FACE);
        fill(c, il, it, ir, it + u, hi);          // top
        fill(c, il, it, il + u, ib, hi);          // left
        fill(c, il, ib - u, ir, ib, lo);          // bottom
        fill(c, ir - u, it, ir, ib, lo);          // right

        if (!pressed) {
            fill(c, il, it, il + u, it + u, CORNER_TL);
            fill(c, ir - u, it, ir, it + u, CORNER_TR);
            fill(c, il, ib - u, il + u, ib, CORNER_BL);
            fill(c, ir - u, ib - u, ir, ib, CORNER_BR);
        } else {
            fill(c, il, it, il + u, it + u, SHADOW);
            fill(c, ir - u, ib - u, ir, ib, HIGHLIGHT);
        }
    }

    @Override public void setAlpha(int alpha) {}
    @Override public void setColorFilter(ColorFilter colorFilter) {}
    @Override public int getOpacity() { return PixelFormat.OPAQUE; }
}
