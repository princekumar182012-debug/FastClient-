package org.levimc.launcher.ui.activities;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;

import org.levimc.launcher.R;
import org.levimc.launcher.ui.views.SkinPreviewView;
import org.levimc.launcher.util.CosmeticsStore;

public class CosmeticsActivity extends BaseActivity {

    private static final int[] TAG_COLORS = {
            0xFFFF7A1A, 0xFFFFC83D, 0xFFFF4D4D, 0xFFE040FB, 0xFF4DA3FF, 0xFF2DE0A0, 0xFFFFFFFF
    };

    private SkinPreviewView preview;
    private boolean capeMode;

    private final ActivityResultLauncher<String[]> capePicker =
            registerForActivityResult(new ActivityResultContracts.OpenDocument(), uri -> {
                if (uri == null) return;
                if (CosmeticsStore.saveCape(this, uri)) {
                    preview.setCape(CosmeticsStore.loadCape(this));
                    preview.setShowBack(true);
                    Toast.makeText(this, "Cape saved", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Use a PNG cape of size 64x32 (or 128x64)", Toast.LENGTH_LONG).show();
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cosmetics);
        capeMode = "cape".equals(getIntent().getStringExtra("mode"));

        preview = findViewById(R.id.cosmetics_preview);
        TextView title = findViewById(R.id.cosmetics_title);
        TextView desc = findViewById(R.id.cosmetics_desc);
        LinearLayout colorRow = findViewById(R.id.cosmetics_color_row);
        TextView pick = findViewById(R.id.cosmetics_btn_pick);
        TextView clear = findViewById(R.id.cosmetics_btn_clear);

        preview.setSkin(CosmeticsStore.loadSkin(this));
        preview.setCape(CosmeticsStore.loadCape(this));

        if (capeMode) {
            title.setText("Capes");
            desc.setText("Import a cape PNG (64x32). Tap the player to turn around and see it.");
            colorRow.setVisibility(View.GONE);
            pick.setVisibility(View.VISIBLE);
            clear.setVisibility(View.VISIBLE);
            preview.setShowBack(true);
            pick.setOnClickListener(v -> capePicker.launch(new String[]{"image/png"}));
            clear.setOnClickListener(v -> {
                CosmeticsStore.clearCape(this);
                preview.setCape(null);
            });
        } else {
            title.setText("Nametag");
            desc.setText("Choose the colour of the Fast Client logo shown before your name.");
            pick.setVisibility(View.GONE);
            clear.setVisibility(View.GONE);
            colorRow.setVisibility(View.VISIBLE);
            int selected = CosmeticsStore.getTagColor(this);
            preview.setTag(true, "Player", selected);
            buildSwatches(colorRow, selected);
        }
    }

    private void buildSwatches(LinearLayout row, int selected) {
        row.removeAllViews();
        float d = getResources().getDisplayMetrics().density;
        int size = (int) (34 * d);
        for (int color : TAG_COLORS) {
            View v = new View(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(size, size);
            lp.setMarginEnd((int) (10 * d));
            v.setLayoutParams(lp);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(color);
            g.setStroke((int) ((color == selected ? 3 : 1) * d), color == selected ? Color.WHITE : 0x55FFFFFF);
            v.setBackground(g);
            v.setOnClickListener(x -> {
                CosmeticsStore.setTagColor(this, color);
                preview.setTag(true, "Player", color);
                buildSwatches(row, color);
            });
            row.addView(v);
        }
    }
}
