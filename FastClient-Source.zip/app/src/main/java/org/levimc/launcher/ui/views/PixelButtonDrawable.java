package org.levimc.launcher.ui.views;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;

/**
 * Chunky pixel style button (dark outline with notched corners, flat coloured face,
 * light top edge and darker bottom edge) like the Minecraft launcher buttons.
 */
public class PixelButtonDrawable extends Drawable {
    private static final int BORDER = 0xFF0E0E0E;
    private static final int TOP_LIGHT = 0x61FFFFFF;
    private static final int BOTTOM_DARK = 0x4D000000;

    private final int face;
    private final float d;
    private final Paint paint = new Paint();
    private final Path outer = new Path();
    private final Path inner = new Path();

    public PixelButtonDrawable(int faceColor, float density) {
        this.face = faceColor;
        this.d = density;
        paint.setAntiAlias(false);
        paint.setStyle(Paint.Style.FILL);
    }

    private static void notched(Path p, float l, float t, float r, float b, float n, float m) {
        p.reset();
        p.moveTo(l + n, t);
        p.lineTo(r - n, t);
        p.lineTo(r - n, t + m);
        p.lineTo(r, t + m);
        p.lineTo(r, b - m);
        p.lineTo(r - n, b - m);
        p.lineTo(r - n, b);
        p.lineTo(l + n, b);
        p.lineTo(l + n, b - m);
        p.lineTo(l, b - m);
        p.lineTo(l, t + m);
        p.lineTo(l + n, t + m);
        p.close();
    }

    @Override
    public void draw(Canvas c) {
        Rect b = getBounds();
        if (b.width() <= 0 || b.height() <= 0) return;
        float bw = Math.max(2f, 2f * d);

        notched(outer, b.left, b.top, b.right, b.bottom, Math.max(3f, 3f * d), Math.max(2f, 1.5f * d));
        paint.setColor(BORDER);
        c.drawPath(outer, paint);

        float il = b.left + bw, it = b.top + bw, ir = b.right - bw, ib = b.bottom - bw;
        if (ir <= il || ib <= it) return;
        notched(inner, il, it, ir, ib, Math.max(2f, 2f * d), Math.max(1f, d));
        paint.setColor(face);
        c.drawPath(inner, paint);

        int save = c.save();
        c.clipPath(inner);
        paint.setColor(TOP_LIGHT);
        c.drawRect(il, it, ir, it + 3f * d, paint);
        paint.setColor(BOTTOM_DARK);
        c.drawRect(il, ib - 5f * d, ir, ib, paint);
        c.restoreToCount(save);
    }

    @Override public void setAlpha(int alpha) {}
    @Override public void setColorFilter(ColorFilter colorFilter) {}
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}
