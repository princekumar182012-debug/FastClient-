# Fast Client

Minecraft Bedrock launcher for Android, based on LeviLaunchroid (LeviMC Team, Apache 2.0).
See NOTICE and LICENSE.

## APK banane ka tareeka
1. Is repo ko GitHub par upload karo (ya fork par ye files copy karo).
2. Actions tab > "Build Fast Client APK" > Run workflow.
3. Khatam hone par Artifacts > Fast-Client-apk download karo, zip kholo, APK install karo.
